export const LEFT_ARROW = '«'
export const RIGHT_ARROW = '»'
export const ELLIPSES = '…'
