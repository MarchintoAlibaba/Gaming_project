weixinTip
=========

show a tip when download something at wechat app. for all you can check at http://caibaojian.com/weixin-tip.html
